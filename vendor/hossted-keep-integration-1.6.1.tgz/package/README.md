# @hossted/keep-integration

React components embedding Hossted's analysis widget into a host app (e.g. Keep).

## Install

```sh
npm install @hossted/keep-integration
```

### Installing without a registry

Build it from this repo:

```sh
pnpm build
npm pack   # produces hossted-keep-integration-<version>.tgz
```

Then install that file from the host app, either as a local path or committed into the host repo and installed from there:

```sh
npm install ../keep-npm-widget/hossted-keep-integration-1.2.0.tgz
# or, once copied into the host repo:
npm install ./vendor/hossted-keep-integration-1.2.0.tgz
```

## Setup

Import the stylesheet once, alongside the components:

```tsx
import "@hossted/keep-integration/styles.css";
```

- `HosstedWrapper` - supplies tooltip context to `HosstedButton`.
- `HosstedButton` - the click-to-analyze button for one item.
- `HosstedSidebarSection` - renders the side panel for a request once analyzed.

With the side panel enabled (the default), track which request's panel is open in your own state and pass it to `HosstedSidebarSection`:

```tsx
import { HosstedWrapper, HosstedButton, HosstedSidebarSection } from "@hossted/keep-integration";

<HosstedWrapper>
  <HosstedButton request={request} onOpenDetail={(request) => setOpenRequest(request)} />
  {openRequest && <HosstedSidebarSection request={openRequest} />}
</HosstedWrapper>
```

With the Hossted side panel disabled, just the button:

```tsx
import { HosstedWrapper, HosstedButton } from "@hossted/keep-integration";

<HosstedWrapper>
  <HosstedButton request={request} disableHosstedSidePanel />
</HosstedWrapper>
```

### Config values

| Variable | Description |
| --- | --- |
| `HOSSTED_PROXY_URL` | The analysis endpoint. Read in `useHosstedResponse` as the URL every `HosstedButton` click POSTs to. |
| `HOSSTED_API_TOKEN` | Bearer token sent with each request to your own proxy (not Hossted's real token - see above). |
| `HOSSTED_DASHBOARD_URL` | Read in `HosstedSidebarSection` to build the "Continue with Hossted" link. |
| `HOSSTED_TOAST_DISABLED` | Set to `"true"` to turn off the response toast notifications rendered by `HosstedWrapper`. Unlike the per-button props below, this is a single app-wide switch (the toast only ever mounts once, at the wrapper). Default: toasts enabled. |

Edit your `vite.config.ts` (or equivalent bundler config) to inline them at build time:

```ts
define: {
  "process.env.HOSSTED_PROXY_URL": JSON.stringify(process.env.HOSSTED_PROXY_URL),
  "process.env.HOSSTED_API_TOKEN": JSON.stringify(process.env.HOSSTED_API_TOKEN),
  "process.env.HOSSTED_DASHBOARD_URL": JSON.stringify(process.env.HOSSTED_DASHBOARD_URL),
  "process.env.HOSSTED_TOAST_DISABLED": JSON.stringify(process.env.HOSSTED_TOAST_DISABLED),
}
```

or the equivalent for your bundler (webpack's `DefinePlugin`, Next.js's `env` config key, etc.).

### `HosstedButton` properties

| Property | Type | Description |
| --- | --- | --- |
| `request` | `HosstedRequest` | The item being analyzed - see below. |
| `onOpenDetail` | `(request) => void` | Fires on click, only when `disableHosstedSidePanel` is `false` and a response already exists for this request. |
| `disableHosstedSidePanel` | `boolean` | Suppresses `onOpenDetail` - the button still fetches and shows status/tooltip, but clicking a completed request does nothing further. Default `false`. |
| `disableTooltip` | `boolean` | Hides the hover tooltip (summary/error preview) entirely. Default `false`. |

### `HosstedRequest` fields

| Field | Type | Description |
| --- | --- | --- |
| `fingerprint` | `string` | The alert's fingerprint, not Keep's own alert id - it's the cache key and "already analyzed?" lookup, so a mismatch fails silently: nothing restores on refresh, and alerts get re-analyzed forever. |
| `payload` | `Record<string, unknown>` | Sent to the analysis endpoint verbatim, as the request body's `payload` object. Put whatever fields Hossted's backend for your integration expects - this package doesn't constrain its shape. |

Both flags are per-instance - there is no global switch, so pass them on every `<HosstedButton>` you render if you want the behavior everywhere:

```tsx
<HosstedButton request={request} onOpenDetail={onOpenDetail} disableTooltip disableHosstedSidePanel />
```

## Hooking into responses (e.g. persisting to your own storage)

Use `subscribeHosstedResponses` to react whenever a response finishes. It fires for `"success"`/`"error"` results the widget itself got back from the analysis endpoint; it does not fire for `"loading"`, or for a response you seeded yourself via `setHosstedResponse`/`refreshHosstedResponse`. This is how a host app saves results into its own backend as they arrive, so they can be restored on a later page load.

```tsx
import { subscribeHosstedResponses } from "@hossted/keep-integration";

const stopHosstedSubscription = subscribeHosstedResponses((response) => {
  saveToMyBackend(response.id, response);
});

// call stopHosstedSubscription() on teardown (e.g. in a useEffect cleanup)
```

## Restoring a response on page load

Two functions seed the store with a saved response:

- `setHosstedResponse(response)` - only sets it if nothing's there yet. Use this if you have one source (e.g. one backend). Safe to call on load - won't overwrite a click already in progress.
- `refreshHosstedResponse(response)` - always overwrites, unless a click is in progress. Use this for a second, authoritative source (like a backend Redis cache), alongside a fast local cache: paint from the cache with `setHosstedResponse`, then call this once your backend answers.

```tsx
import { setHosstedResponse, refreshHosstedResponse } from "@hossted/keep-integration";

// 1. instant paint from a fast cache, if you have one
const cached = readFromMyFastCache(request.fingerprint);
if (cached) setHosstedResponse(cached);

// 2. then check your real backend, and let it win
const saved = await fetchFromMyBackend(request.fingerprint);
if (saved) refreshHosstedResponse(saved);
```


## Why `HOSSTED_PROXY_URL` must be your own backend

**The widget cannot talk to Hossted directly: it has no memory, and it has no safe place to hold your API credential.**

- No memory: the widget only holds state in the browser tab. Refresh the page and it's gone - something has to be able to answer "what did Hossted already say about this?" on load, and that has to be a server, not the widget.
- No safe credential storage: `HOSSTED_API_TOKEN` authenticates *your* account with Hossted. Anything shipped to the browser is visible to anyone who opens dev tools - so the real Hossted token can only ever live server-side, in your proxy, never in the widget's own config.

So `HOSSTED_PROXY_URL` always points at a route on **your own backend**, never at Hossted's real endpoint. Your proxy is the only thing that holds the real Hossted token and talks to Hossted; the widget only ever talks to you. Contract your proxy needs to implement:

- `POST <proxy>?id=<id>` - forward the request body to Hossted's real endpoint (with your real token attached), return its JSON response, and persist it somewhere keyed by `id` if you want it to survive a page reload.
- `GET <proxy>?id=<id>` - return the persisted response for `id` if you have one (`200` + the same JSON shape), or `404` if you don't. The widget's host app calls this on page load to restore a prior result - see "Restoring a response on page load" above.